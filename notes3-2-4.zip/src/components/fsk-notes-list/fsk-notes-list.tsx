import { Component, ComponentInterface, h } from '@stencil/core';

/** 
 * Lists notes
*/
@Component({
  tag: 'fsk-notes-list',
  styleUrl: 'fsk-notes-list.css',
  shadow: true,
})
export class FskNotesList implements ComponentInterface {

  render() {
    return (
      <div>TODO: Create notes-list render</div>
    );
  }

}
